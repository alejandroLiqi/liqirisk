#' Comuni Short
#'
#' A table containing a lookup table ready for comune to area geografica.
#'
#' @format A data.table of 8258 rows and 5 columns
#' \describe{
#'  ...
#' }
#' @author Alejandro Abraham
#' @source ISTAT
"comuni_short"
