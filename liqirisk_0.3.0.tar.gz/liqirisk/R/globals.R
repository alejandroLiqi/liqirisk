utils::globalVariables(c("CLIENT", "DS1", "DS2", "PROJECT", 'MAINTAINER', 'CREATOR', "meta", "nodata","git_init" ,"initcommit", "remote_origin"))

#tools::buildVignettes(dir = ".", tangle=TRUE)
#dir.create("inst/doc")
#file.copy(dir("vignettes", full.names=TRUE), "inst/doc", overwrite=TRUE)
